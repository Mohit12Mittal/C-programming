#include<stdio.h>
int main()
{
    int num;
    printf("Enter the value of num");
    scanf("%d",&num);
    int A[50];
    printf("Enter Element of Array");
    for(int i=0;i<num;i++)
    {
        scanf("%d",&A[i]);
    }
    for(int i=0;i<num;i++)
    {
        printf("%d ",A[i]);
    }
    int n;
    printf("Enter the Number that you want to insert at begining");
    scanf("%d",&n);
    for(int i=num+1;i>0;i--)
    {
        A[i]=A[i-1];
    }
    A[0]=n;
    for(int i=0;i<num+1;i++)
    {
        printf("%d\n",A[i]);
    }
    return 0;
}

